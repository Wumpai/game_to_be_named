/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable prettier/prettier */
const WebSocket = require('ws');

//what need to do
//when player join, it adds them and tells all other users somebody join
//when player disconnect it removes them and tells all other users

class Server {
    message(msg) {
        return console.log("[DEBUG]", msg)
    }

    decodeMSG(msg) {
        this.message(msg);
        return JSON.parse(msg);
    }

    constructor(port, game) {
        if (typeof port !== "number")
            return this.message("The server port is not a numeric value");
        if (game === undefined)
            return this.message("The game library are undefined or library does not exists");

        this.port = port;
        this.game = game;
        this.messagesCache = [];
        this.wss = new WebSocket.Server({
            port: port
        });

        console.log("Server started!");

        // working
        this.wss.on("connection", socket => {
            const socketId = String(Math.floor(Math.random() * 10000));
            this.game.createPlayer(socketId);

            //we need to give him all the data of the players already conencted;
            const INITILISE_PACKET = this.game.generateINITPACKET(socketId)
            socket.send(INITILISE_PACKET);

            socket.on("message", data => {
                try {
                    const msg = JSON.parse(data);
                    switch (msg[0]) {
                        case 0:
                            this.game.updatePlayer(socketId, msg[1], msg[2]);
                            break;
                        default:
                            console.log("Got an unknown packet", msg);
                            break;
                    }
                } catch (e) {
                    console.warn("Handled error with WS msg DATA", e);
                }

            });
            socket.on("close", _ => {
                this.game.removePlayer(socketId);
                console.log("Client closed", socketId);
            })
        })
    }
}

module.exports = {
    Server: Server,
}