/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable prettier/prettier */

const {Player} = require('./entity/player');
const {Server} = require("../server/server");

//packets
// 0 update
// 1 create player
// 2 remove player
// 3 initalise packet

class Game{
    constructor(){
        console.log("Initalized game, loading server..");

        this.players = [];
        this.server = new Server(6969, this);

        this.tickLengthMs = 1000 / 3;
        this.previousTick = Date.now();
        this.gameLoop();
    }

    generateINITPACKET(socketID){ // Module: generating initalization packet
        return JSON.stringify([3, socketID]);
    }

    createPlayer(socketID){ // Module: creating player in game
        console.log('[DEBUG] Created new player');
        this.players.push(new Player(socketID, 0, 0));

        if (this.server.wss.clients.length > 0) { // If server are not empty, he will send data
            const createPlayerPacket = JSON.stringify([1, socketID]);
            this.server.wss.clients.forEach(client => {
                if (client.readyState === 1) {
                    client.send(createPlayerPacket);
                }
            })
        }
    }

    updatePlayer(socketID, controlKey, angle){
        for(var i = 0 ; i < this.players.length; i++){
            if(this.players[i].socketID === socketID){
                this.players[i].setKeyState = controlKey;
                this.players[i].angle = angle/100;
                break;
            }
        }
    }

    removePlayer(socketID) {
        for(var i = 0 ; i < this.players.length;i++){
            if(this.players[i].socketID === socketID){
                this.players[i] = null;
                this.players.splice(i,1);
                break;
            }
        }
        const removePlayerPacket = JSON.stringify([2, socketID]);
        this.server.wss.clients.forEach(client => {
            if (client.readyState === 1) {
              client.send(removePlayerPacket);
            }
        });
    }

    generateUpdateData(){ // Module: generating clients update data
        let data = [0];
        for(var i = 0 ; i < this.players.length; i ++){
            data.push([this.players[i].socketID, Math.floor(this.players[i].x*100), Math.floor(this.players[i].y*100), Math.floor(this.players[i].angle*100)])
        }
        return JSON.stringify(data);
    }

    serverUpdateClient(){ // Module: updating client data
        const updateData = this.generateUpdateData();
        this.server.wss.clients.forEach(client => {
            if (client.readyState === 1) {
              client.send(updateData);
            }
        });
    }

    gameLoop() {
        const now = Date.now()

        if (this.previousTick + this.tickLengthMs <= now) {
            const delta = (now - this.previousTick) / 1000
            this.previousTick = now
      
            this.update(delta)
            this.serverUpdateClient();
        }
      
        if (Date.now() - this.previousTick < this.tickLengthMs - 16) {
            setTimeout(this.gameLoop.bind(this))
        } else {
            setImmediate(this.gameLoop.bind(this))
        }
    }

    update(delta){
        //update all the players
        for(var i = 0 ; i < this.players.length; i ++){
            this.players[i].update(delta);
        }
    }
}
module.exports = {
    Game: Game,
}