/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable prettier/prettier */

const {Entity} = require("./entity");
class Bear extends Entity{
    constructor(args){
        super(...args)
    }
}
module.exports = {
    Bear: Bear,
}