/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable prettier/prettier */
const {Entity} = require("./entity");
class Player extends Entity{
    constructor(socketID, x, y){
        super(x,y);
        this._socketID = socketID;
        this._keystate = 0 ;
        this.velocity = 200; //value used by starve.io

    }

    get socketID(){return this._socketID};
    set setKeyState(k){this._keystate = k};
    get keyState(){return this._keystate};

    update(delta){
        const keyState = this.keyState;
        
        if(keyState === 0){
            //he isnt moving
        }else{
            if((keyState | 2) === keyState){
                //up
                this.y -= this.velocity * delta;
            }else if((keyState | 8) === keyState){
                //down
                this.y += this.velocity * delta;
            }

            if((keyState | 4) === keyState){
                //right
                this.x += this.velocity * delta;
            }else if((keyState | 16) === keyState){
                //left
                this.x -= this.velocity * delta;
            }
        }
    }
}
module.exports = {
    Player: Player,
}