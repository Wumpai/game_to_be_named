/* eslint-disable prettier/prettier */
class Entity{
    constructor(x,y){
        this.x = x;
        this.y = y;
        this.angle = 0;
    }

    update(delta){
        console.log('update', delta);
    }
}
module.exports = {
    Entity: Entity,
}
