/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable prettier/prettier */

const {Game} = require("./game/game");
let game = new Game();