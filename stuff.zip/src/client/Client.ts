/* eslint-disable @typescript-eslint/no-explicit-any */
import { Player } from "../entity/Player";
import { Game } from "../engine/Game";
import { Controller } from "./Controller";
import { Network } from "../network/Network";

export class Client {
    private controls!: Controller;
    public player!: Player;
    private game!: Game;
    private network!: Network;
    private players: Map<string, Player> = new Map();
    private angle = 0;
    private controlKey = 0;
    constructor(engine: Game) {
        this.game = engine;
        this.player = engine._EntityFactor.createPlayer(0, 0, 0);
        this.controls = new Controller(engine.renderer.view);
        this.network = new Network({
            address: "localhost:6969",
            ssl: false,
        });
    }

    createPlayer(id: string, x: number, y: number, r: number): void {
        if (this.players.get(id)) return console.log(`player id ${id} already exists`);

        console.log("CREATED A NEW PLAYER", x, y);
        const player = this.game._EntityFactor.createPlayer(x, y, r);
        this.players.set(id, player);
        this.game.instantiate(player);
    }

    updatePlayers(packet: any[]): void {
        for (let i = 1; i < packet.length; i++) {
            const id = packet[i][0];
            const x = packet[i][1] / 100;
            const y = packet[i][2] / 100;
            const r = packet[i][3] / 100;
            const res = this.players.get(id);
            if (res) {
                //if player exists
                res.x = x;
                res.y = y;
                res.angle = r;
            } else {
                this.createPlayer(id, x, y, r);
            }
        }
    }

    removePlayer(packet: any[]): void {
        const player = this.players.get(packet[1]);
        if (player) {
            this.game.remove(player);
            this.players.delete(packet[1]);
        }
    }

    updateServer(): void {
        let controlKey = 0;

        if (this.controls.downKeys["KeyW"]) {
            controlKey += 2;
        }
        if (this.controls.downKeys["KeyD"]) {
            controlKey += 4;
        }
        if (this.controls.downKeys["KeyS"]) {
            controlKey += 8;
        }
        if (this.controls.downKeys["KeyA"]) {
            controlKey += 16;
        }
        if (controlKey != this.controlKey) {
            this.network.send(JSON.stringify([0, controlKey, Math.floor(this.player.angle * 100)]));
            this.controlKey = controlKey;
        }
    }

    applyPackets(packet: any[]): void {
        switch (Number(packet[0])) {
            case 0:
                this.updatePlayers(packet);
                break;
            case 1:
                console.log("creating another boi");
                break;
            case 2:
                this.removePlayer(packet);
                console.log("removing another boi");
                break;
            case 3:
                console.log("player data update to id", packet[1]);
                this.players.set(packet[1], this.player);
                break;
            default:
                console.log("Unknown packet", Number(packet[0]));
                break;
        }
    }

    update(): void {
        for (let i = 0; i < this.network.queueLength; i++) {
            this.applyPackets(this.network.readMessage());
        }

        this.player.angle =
            Math.atan2(this.controls.mouse.y - this.player.y, this.controls.mouse.x - this.player.x) + Math.PI / 2;
        this.player.update();

        this.updateServer();
    }
}
