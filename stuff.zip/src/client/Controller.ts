export class Controller {
    public downKeys: { [key: string]: boolean } = {};
    public mouse = { x: 0, y: 0 };
    constructor(view: HTMLElement) {
        document.addEventListener("keydown", (e: KeyboardEvent) => {
            this.downKeys[e.code] = true;
        });
        document.addEventListener("keyup", (e: KeyboardEvent) => {
            delete this.downKeys[e.code];
        });
        view.addEventListener("mousemove", (e: MouseEvent) => {
            this.mouse.x = e.clientX;
            this.mouse.y = e.clientY;
        });
    }
}
