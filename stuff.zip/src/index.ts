import { Game } from "./engine/Game";
import { EntityFactory } from "./entity/EntityFactor";
import { Client } from "./client/Client";
import "./style.css";

export class Main {
    // i see, chill :)
    private engine!: Game;
    private client!: Client;
    constructor() {
        this.engine = new Game();
        window.onload = (): void => {
            this.startLoadingAssets();
        };
    }

    private beginGame(): void {
        this.client = new Client(this.engine);
        this.engine.instantiate(this.client);

        /*const d = this.engine._EntityFactor.createBear(100, 100);
        d.setTarget(this.client.player);
        this.engine.instantiate(d);

        const e = this.engine._EntityFactor.createBear(120, 400);
        e.setTarget(this.client.player);
        this.engine.instantiate(e);

        const c = this.engine._EntityFactor.createBear(600, 600);
        c.setTarget(this.client.player);
        this.engine.instantiate(c);*/
    }

    private setupEntityFactory(): void {
        const sheet = this.engine.loader.resources["spritesheet"].spritesheet;
        if (!sheet) {
            alert("Unable to load sheet");
            return;
        }
        this.engine._EntityFactor = new EntityFactory(this.engine, {
            playerTexture: sheet.textures["player.svg"],
            bearTexture: sheet.textures["bear.svg"],
        });
    }

    private startLoadingAssets(): void {
        this.engine.loader.add("spritesheet", "./assets/spritesheet.json");

        this.engine.loader.onComplete.once(() => {
            this.setupEntityFactory();
            this.onAssetsLoaded();
        });

        this.engine.loader.load();
    }

    private onAssetsLoaded(): void {
        console.log("Assets loaded");
        const elem = document.getElementById("wrapper");
        if (elem) {
            elem.style.opacity = "0%";
        }
        document.body.appendChild(this.engine.renderer.view);
        this.beginGame();
    }
}

new Main();
