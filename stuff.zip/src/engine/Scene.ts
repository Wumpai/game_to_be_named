import * as PIXI from "pixi.js";
export class Scene extends PIXI.Container {
    constructor() {
        super();
    }

    public instantiate(object: PIXI.Sprite): void {
        this.addChild(object);
    }
}
