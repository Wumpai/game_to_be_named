import * as PIXI from "pixi.js";
import { Player } from "../entity/Player";
import { Scene } from "../engine/Scene";
import { Client } from "../client/Client";
import { EntityFactory } from "../entity/EntityFactor";
import { Entity } from "../entity/Entity";

export class Game {
    public _scene!: Scene;
    public _renderer!: PIXI.Renderer;
    public _players: (Player | Client)[] = [];
    public _loader!: PIXI.Loader;
    public _EntityFactor!: EntityFactory;

    get scene(): PIXI.Container {
        return this._scene;
    }

    get renderer(): PIXI.Renderer {
        return this._renderer;
    }

    get loader(): PIXI.Loader {
        return this._loader;
    }

    constructor() {
        this._scene = new Scene();
        this._renderer = PIXI.autoDetectRenderer({
            width: window.innerWidth,
            height: window.innerHeight,
            backgroundColor: 0x072469,
        });
        requestAnimationFrame(this.tick.bind(this));
        this._loader = new PIXI.Loader();
    }

    public remove(entity: Entity): void {
        for (let i = 0; i < this._players.length; i++) {
            if (entity === this._players[i]) {
                this._players.splice(i, 1);
                break;
            }
        }
        this.scene.removeChild(entity.container);
        entity.container.destroy();
    }

    public instantiate(updateable: Player | Client): void {
        if (updateable instanceof Client) {
            this._players.push(updateable);
            this.scene.addChild(updateable.player.container);
            return;
        }
        if (updateable instanceof Entity) {
            this._players.push(updateable);
            this.scene.addChild(updateable.container);
            return;
        }
        this._players.push(updateable);
    }

    tick(): void {
        requestAnimationFrame(this.tick.bind(this));

        //update players
        for (let i = 0; i < this._players.length; i++) {
            this._players[i].update();
        }

        //draw
        this._renderer.render(this._scene);
    }
}
