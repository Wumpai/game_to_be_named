/* eslint-disable @typescript-eslint/no-explicit-any */
export class Network {
    private socket!: WebSocket;
    private _messages: any = [];

    get queueLength(): number {
        return this._messages.length;
    }

    constructor({ address = "127.0.0.1:6969", ssl = false }: { address?: string; ssl?: boolean }) {
        const protocol = ssl ? "wss" : "ws";

        this.socket = new WebSocket(`${protocol}://${address}`);
        this.socket.addEventListener("open", function () {
            console.log("Successfully connected");
        });
        this.socket.addEventListener("message", this.message.bind(this));
    }

    private message(data: MessageEvent) {
        this._messages.push(data.data);
    }

    public send(data: string): void {
        this.socket.send(data);
    }

    public readMessage(): any {
        const msg = this._messages[0];
        this._messages.shift(); //this isnt removing the first value
        return JSON.parse(msg);
    }
}
