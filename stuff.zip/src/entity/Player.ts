import * as PIXI from "pixi.js";
import { Entity } from "./Entity";

export class Player extends Entity {
    constructor(texture: PIXI.Texture, x: number, y: number, r: number) {
        super(texture, x, y, r);
    }
}
