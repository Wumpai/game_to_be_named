import * as PIXI from "pixi.js";

export class Entity {
    public body!: PIXI.Sprite;
    public container!: PIXI.Container;
    public target!: Entity;
    public follow = false;
    public x!: number;
    public y!: number;
    public angle = 0;

    public setTarget(entity: Entity): void {
        this.target = entity;
        this.follow = true;
    }

    constructor(texture: PIXI.Texture, x: number, y: number, r: number) {
        this.x = x;
        this.y = y;
        this.angle = r;
        this.container = new PIXI.Container();
        this.container.position.set(x, y);
        this.body = new PIXI.Sprite(texture);
        this.body.anchor.set(0.5);
        this.container.addChild(this.body);
    }

    public update(): void {
        this.container.position.set(this.x, this.y);
        this.container.rotation = this.angle;
    }
}
