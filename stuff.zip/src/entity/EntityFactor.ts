import * as PIXI from "pixi.js";
import { Game } from "../engine/Game";
import { Player } from "./Player";
import { Bear } from "./Bear";

export class EntityFactory {
    private playerTexture!: PIXI.Texture;
    private bearTexture!: PIXI.Texture;
    private emptyTexture!: PIXI.Texture;
    private engine!: Game;
    private generateEmpty(): PIXI.Texture {
        const g = new PIXI.Graphics();
        g.beginFill(0xf5cb42);
        g.drawRect(0, 0, 100, 100);
        g.endFill();
        return this.engine.renderer.generateTexture(g, PIXI.SCALE_MODES.NEAREST, 1);
    }

    public createPlayer(x: number, y: number, r: number): Player {
        return new Player(this.playerTexture, x, y, r);
    }

    public createBear(x: number, y: number): Player {
        return new Bear(this.bearTexture, x, y);
    }

    constructor(engine: Game, options: { playerTexture?: PIXI.Texture; bearTexture?: PIXI.Texture }) {
        this.engine = engine;
        this.emptyTexture = this.generateEmpty();

        if (options.playerTexture) {
            this.playerTexture = options.playerTexture;
        } else {
            this.playerTexture = this.emptyTexture;
        }

        if (options.bearTexture) {
            this.bearTexture = options.bearTexture;
        } else {
            this.bearTexture = this.emptyTexture;
        }
    }
}
