import * as PIXI from "pixi.js";
import { Entity } from "./Entity";

export class Bear extends Entity {
    private originalWidth!: number;
    private originalHeight!: number;
    private tick = 0;
    private lastUpdate = performance.now();
    private nextPoint = { x: 0, y: 0 };
    private velocity = { x: 0, y: 0 };
    constructor(texture: PIXI.Texture, x: number, y: number) {
        super(texture, x, y, 0);
        this.originalWidth = this.container.width;
        this.originalHeight = this.container.height;
    }

    public max(a: number, b: number): number {
        return a > b ? 0 : a;
    }

    public limit(a: number, lim: number): number {
        if (a < 0) {
            return a < lim ? -1 * lim : a;
        }
        return a > lim ? lim : a;
    }

    public unit(a: number): number {
        return Math.floor(a) / Math.abs(Math.floor(a) | 1);
    }

    update(): void {
        const now = performance.now();

        if (now - this.lastUpdate > 1200) {
            this.container.rotation =
                Math.atan2(
                    this.container.y + this.body.y - (this.target.container.y + this.target.body.y),
                    this.container.x + this.body.x - (this.target.container.x + this.target.body.x)
                ) +
                Math.PI / 2;
            this.nextPoint.x = this.target.container.x + this.target.body.x;
            this.nextPoint.y = this.target.container.y + this.target.body.y;
            this.lastUpdate = now;
            return;
        }

        if (now - this.lastUpdate > 800) {
            this.velocity.x = 0;
            this.velocity.y = 0;
            return;
        }
        this.container.x += 3 * this.unit(-1 * (this.container.x + this.body.x - this.nextPoint.x));
        this.container.y += 3 * this.unit(-1 * (this.container.y + this.body.y - this.nextPoint.y));
    }
}
